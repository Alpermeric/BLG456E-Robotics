catkin make:
>> cd ~/catkin_ws
>> catkin_make
>> cd src

Open three seperate terminals

gazebo:

>> roslaunch my_simulation pista_s.launch

rviz:

>> roslaunch mybot_description mybot_control2.launch

robot controller:

>> cd my_simulation
>> python main.py


