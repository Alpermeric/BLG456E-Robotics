#!/usr/bin/env python
#!/usr/bin/env python
## AK
## explorer_node_py.py
##
## BLG456E Assignment 1 skeleton
##
## Instructions: Change the laser_callback function to make the robot explore more
## intelligently, using its sensory data (the laser range array).
##
## Advanced: If you want to make use of the robot's mapping subsystem then you can
## make use of the map in the mapping_callback function.
##
## 

## Common ROS headers.
import rospy
## Required for some printing options
import sys
import math
## This is needed for the data structure containing the motor command.
from geometry_msgs.msg import Twist
## This is needed for the data structure containing the laser scan
from sensor_msgs.msg import LaserScan
## This is needed for the data structure containing the map (which you may not use).
from nav_msgs.msg import OccupancyGrid
import time

## The following function is a "callback" function that is called back whenever a new laser scan is available.
## That is, this function will be called for every new laser scan.
##
## --------------------------------------------------------------------------------
## ----------CHANGE THIS FUNCTION TO MAKE THE ROBOT EXPLORE INTELLIGENTLY----------
## --------------------------------------------------------------------------------
##


class Actions:
    FORWARD = 1
    BACKWARD = 2
    TURN_LEFT = 3
    TURN_RIGHT = 4
    FORWARD_LEFT = 5
    FORWARD_RIGHT = 6
    SLIGHTLY_LEFT = 7
    SLIGHTLY_RIGHT = 8

def move_robot(action):
    global motor_command_publisher
    motor_command = Twist()
    if action == Actions.FORWARD:
        motor_command.linear.x = 0.5
        motor_command.angular.z = 0.0
    elif action == Actions.BACKWARD:
        motor_command.linear.x = -0.25
        motor_command.angular.z = 2
    elif action == Actions.TURN_LEFT:
        motor_command.linear.x = 0.0
        motor_command.angular.z = 1.0
    elif action == Actions.TURN_RIGHT:
        motor_command.linear.x = 0.0
        motor_command.angular.z = -1.0
    elif action == Actions.FORWARD_RIGHT:
        motor_command.linear.x = 0.5
        motor_command.angular.z = -0.5
    elif action == Actions.FORWARD_LEFT:
        motor_command.linear.x = 0.33
        motor_command.angular.z = 0.33
    else: # Stop if action not defined
        motor_command.linear.x = 0.0
        motor_command.angular.z = 0.0
    
    global motor_command_publisher
    motor_command_publisher.publish(motor_command)
  

def wall_detection(data): # A function for wall detection with a bound distance 0.9, if true, there is a wall at that part
	return[data.ranges[-1] < 1, data.ranges[len(data.ranges)/2] < 1, data.ranges[1] < 1]


def laser_callback(data):
    ## Lets fill a twist message for motor command
    print(wall_detection(data))
    ## For now let us just set it up to drive forward ...
    if((wall_detection(data))[0] == 1 ):
      move_robot(0)
      move_robot(Actions.BACKWARD)
    else:
      if((wall_detection(data))[1] == 1 ):
        move_robot(0)
        move_robot(Actions.TURN_LEFT)
      else:
        move_robot(Actions.FORWARD)  
    

   
def explorer_node():
    ## We must always do this when starting a ROS node - and it should be the first thing to happen
    rospy.init_node('amble')
    
    ## Here we declare that we are going to publish "Twist" messages to the topic /cmd_vel_mux/navi. It is defined as global because we are going to use this publisher in the laser_callback.
    global motor_command_publisher
    motor_command_publisher = rospy.Publisher('/cmd_vel', Twist, queue_size = 10)
    
    ## Here we set the function laser_callback to recieve new laser messages when they arrive
    rospy.Subscriber("/scan", LaserScan, laser_callback, queue_size = 1000)
    
    
    ## spin is an infinite loop but it lets callbacks to be called when a new data available. That means spin keeps this node not terminated and run the callback when nessessary. 
    rospy.spin()
    
if __name__ == '__main__':
    explorer_node()
