import math
import time
import rospy
import tf2_ros
import actionlib
import tf_conversions
from tf import transformations
from geometry_msgs.msg import Twist
from std_msgs.msg import String, Int32, Float64
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal

def to_euler(x,y,z,w):
    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    X = math.atan2(t0, t1)

    t2 = +2.0 * (w * y - z * x)
    t2 = +1.0 if t2 > +1.0 else t2
    t2 = -1.0 if t2 < -1.0 else t2
    Y = math.asin(t2)

    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    Z = math.atan2(t3, t4)

    return X, Y, Z


def distance(x1,y1,x2,y2):
    return math.sqrt((x1-x2)**2 + (y1-y2)**2)

def to_waypoint(waypoint_x, waypoint_y):
    # rospy.init_node('driver')
    motor_command_publisher = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
    
    

    tf_buffer = tf2_ros.Buffer()
    listener = tf2_ros.TransformListener(tf_buffer)
    delay = rospy.Rate(1.0)

    current_time = time.time()
    last_time = time.time()
    last_error = 0
    cumulative_error = 0
    while not rospy.is_shutdown():
        try:
            #grab the latest available transform from the odometry frame (robot's original location - usually the same as the map unless the odometry becomes inaccurate) to the robot's base.
            
            odom = tf_buffer.lookup_transform("odom", "base_footprint", rospy.Time())
        except  Exception as e:
            print("EXCEPTION:",e)
            #if something goes wrong with this just go to bed for a second or so and wake up hopefully refreshed.
            delay.sleep()
            continue

        motor_command = Twist()
        #grab the latest available transform from the odometry frame (robot's original location - usually the same as the map unless the odometry becomes inaccurate) to the robot's base.
        
        
        translation = odom.transform.translation
        rotation = odom.transform.rotation

        robot_theta = to_euler(rotation.x, rotation.y, rotation.z, rotation.w)[2]

        current_time = time.time()
        delta_time = current_time - last_time
        last_time = current_time
        
        robot_x = translation.x
        robot_y = translation.y

        distance_threshold = 0.1
        angle_threshold = math.pi/18

        is_distance_close = distance(waypoint_x,waypoint_y,robot_x,robot_y) <= distance_threshold
        
        if(is_distance_close):
            return
        else:
            y_dif = waypoint_y - robot_y
            x_dif = waypoint_x - robot_x
            error = (robot_theta - math.atan2(y_dif,x_dif)) % (math.pi * 2) # angle difference betwen position vector and robot' orientation
            motor_command.linear.x = 0.2
            if error > math.pi:
                error -= math.pi*2
                # print "MOVE FORWARD"
            kp, kd, ki = 1.4, 1.1, 0.1
            
        cumulative_error += error * delta_time
        last_error = error

        u_t = (kp * error) + (kd * (error - last_error) / delta_time) + (ki * cumulative_error)
        print error, cumulative_error, last_error, u_t
        motor_command.angular.z = -u_t

        motor_command_publisher.publish(motor_command)

        delay.sleep()