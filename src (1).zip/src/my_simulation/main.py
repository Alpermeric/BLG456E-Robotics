import move
import math
import time
import rospy
import gripper
import follower_p
from stop import stop
from turn import turn


if __name__ == "__main__": 
    TOY_ZONE = (0,0)
    # move.to_waypoint(-1, 1)
    # stop()
    # time.sleep(2)

    # move.to_waypoint(0, 0)
    # stop()
    # time.sleep(2)

    # move.to_waypoint(-5, 2)
    # stop()
    # time.sleep(2)

    rospy.init_node('crazy_bot')
    follower = follower_p.Follower()
    _gripper = gripper.Gripper()
    # rospy.sleep(1.0)
    # _gripper.joint_1.publish(0)

    while True:
        while not follower.is_object_reached:
            print "whiledayim"
        stop()
        print "ready to grip"
        _gripper.grip()
        stop()
        print "gripped"
        move.to_waypoint(*TOY_ZONE)
        stop()
        print "reached toy zone"
        time.sleep(2)
        _gripper.release()
        stop()
        print "released"
        turn(math.pi)
        follower.is_object_reached = False


    # while not follower.is_object_reached:
    #     pass
