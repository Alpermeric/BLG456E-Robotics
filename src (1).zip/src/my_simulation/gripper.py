import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import String, Int32, Float64

class Gripper:
    def __init__(self):
        self.joint_1 = rospy.Publisher("/joint1_position_controller/command",Float64,queue_size=1)
        self.joint_2 = rospy.Publisher("/joint2_position_controller/command",Float64,queue_size=1)
        self.joint_3 = rospy.Publisher("/joint3_position_controller/command",Float64,queue_size=1)
        self.cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
        self.twist = Twist()

    def grip(self):
        rospy.sleep(1.0)
        self.joint_1.publish(0)
        rospy.sleep(1.0)
        self.joint_2.publish(-1)
        self.joint_3.publish(-1)
        rospy.sleep(1.0)

        self.twist.linear.x = 0.07 # get a little closer to toy
        self.cmd_vel.publish(self.twist)
        rospy.sleep(1.0)
        
        self.joint_2.publish(0)
        self.joint_3.publish(0)
        rospy.sleep(1.0)
        self.joint_1.publish(1)

    def release(self):
        rospy.sleep(1.0)
        self.joint_1.publish(0)
        rospy.sleep(1.0)
        self.joint_2.publish(-1)
        self.joint_3.publish(-1)
        rospy.sleep(1.0)
        self.joint_2.publish(0)
        self.joint_3.publish(0)
        self.joint_1.publish(-1)

if __name__ == "__main__":
    rospy.init_node("gripper")

    joint_1 = rospy.Publisher("/joint1_position_controller/command",Float64,queue_size=1)
    joint_2 = rospy.Publisher("/joint2_position_controller/command",Float64,queue_size=1)
    joint_3 = rospy.Publisher("/joint3_position_controller/command",Float64,queue_size=1)

    delay = rospy.Rate(1.0)
    
    rospy.loginfo("Publisher has been started.")

    try:
        
        while not rospy.is_shutdown():
            rospy.loginfo("Grip State")
            
            #var = input("-1  ----  1")

            #joint_1.publish(float(var))

            grip()

            rospy.sleep(4.0)
            rospy.loginfo("Release State")

            release()

            rospy.sleep(4.0)
    except rospy.ROSInterruptException:
        print("An exception has occured")   