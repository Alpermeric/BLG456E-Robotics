#!/usr/bin/env python
# -*- coding:utf-8 -*-


#   exemplo adaptado do livro:
#   
#  Programming Robots with ROS.
#  A Practical Introduction to the Robot Operating System
import rospy
import numpy as np
import math
import cv2
import time
from sensor_msgs.msg import Image, CompressedImage, LaserScan
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge, CvBridgeError

class Follower:

    def __init__(self):
        self.bridge = CvBridge()
        self.cv_image = None
        self.image_sub = rospy.Subscriber('/camera/image/compressed',
                                            CompressedImage, 
                                            self.image_callback, 
                                            queue_size=4, 
                                            buff_size = 2**24)
        self.cmd_vel_pub = rospy.Publisher('/cmd_vel',
                                            Twist, 
                                            queue_size=1)
        
        self.laser_subscriber = rospy.Subscriber('/scan',
                                                 LaserScan, 
			                                    self.laser_callback)
        
        self.twist = Twist()
        self.laser_msg = LaserScan()
        
        self.lastError = 0
        self.max_vel_linear = 0.2
        self.max_vel_angular = 2.0
        self.herts = 250
        self.rate = rospy.Rate(self.herts)
        self.is_object_reached = False

    def laser_callback(self, msg):
        self.laser_msg = msg

    def get_laser(self, pos):
        return self.laser_msg.ranges[pos]
    
    def image_callback(self, msg):
        if self.is_object_reached:
            print "ulastim bence"
            return
        try:
            cv_image = self.bridge.compressed_imgmsg_to_cv2(msg,desired_encoding='bgr8')
            hsv = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)
            lower_yellow = np.array([0, 0, 0],dtype=np.uint8)
            upper_yellow = np.array([255, 255, 15],dtype=np.uint8)
            mask = cv2.inRange(hsv, lower_yellow, upper_yellow)
            _,contours,hierarchy = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            # find largest area contour
            max_area = -1
            for i in range(len(contours)):
                area = cv2.contourArea(contours[i])
                if area>max_area:
                    cnt = contours[i]
                    max_area = area
            h, w, d = cv_image.shape
            M = cv2.moments(mask)
            print("max", max_area)
            # If object is found
            if M['m00'] > 0 and max_area < 23000:
                cx = int(M['m10']/M['m00'])
                cy = int(M['m01']/M['m00'])
                print(cx,cy)
                cv2.circle(cv_image, (cx, cy), 20, (0,0,255), -1)
                ### BEGIN CONTROL
                err = cx - w/2
                self.twist.linear.x = 0.2
                self.twist.angular.z = -float(err) / 100
                self.cmd_vel_pub.publish(self.twist)
                rospy.loginfo("linear: %f angular: %f", self.twist.linear.x, self.twist.angular.z)
                self.rate.sleep()
            else: # Call stop!!!
                self.twist.linear.x = 0
                self.twist.angular.z = 0
                self.cmd_vel_pub.publish(self.twist)
                rospy.loginfo("linear: %f angular: %f", self.twist.linear.x, self.twist.angular.z)
                self.is_object_reached = True
                self.rate.sleep()
            cv2.imshow("mask", mask)
            cv2.imshow("window", cv_image)
            cv2.waitKey(1)
        except Exception as e:
            print('ex', e)

