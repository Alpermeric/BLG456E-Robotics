import rospy
from geometry_msgs.msg import Twist

def stop():
    motor_command_publisher = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
    motor_command = Twist() # zero
    motor_command_publisher.publish(motor_command)